<div class="changepass">
Password updated. Back to <a href="main.php">Home Page</a>
</div>