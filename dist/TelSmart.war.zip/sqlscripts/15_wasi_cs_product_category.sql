CREATE TABLE wasi_cs_product_category(
product_category_id VARCHAR(3) PRIMARY KEY ,
product_category_name VARCHAR( 30 ) NOT NULL ,
product_category_description VARCHAR( 30 ) NOT NULL 
)