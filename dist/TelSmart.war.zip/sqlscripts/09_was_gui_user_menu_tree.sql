CREATE TABLE was_gui_user_menu_tree(
group_id VARCHAR( 8 ) NOT NULL ,
node_number int( 4 ) NOT NULL ,
menu_id VARCHAR( 30 ) NOT NULL ,
menu_name VARCHAR( 30 ) NOT NULL ,
parent_id int( 2 ) NOT NULL,
module_name VARCHAR( 20 ) NOT NULL
)