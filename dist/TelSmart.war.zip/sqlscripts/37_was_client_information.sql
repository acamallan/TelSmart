create table was_client_information(
institution_id varchar(4) not null primary key,
institution_name varchar(30) not null,
record_date varchar(10) not null
)