CREATE TABLE was_product_payment_header(
payment_id varchar(15) not null primary key,
customer_id VARCHAR( 10 ) NOT NULL,
record_date VARCHAR( 10 ) NOT NULL,
userid VARCHAR( 6 ) NOT NULL
)