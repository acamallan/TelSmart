CREATE TABLE was_sale_info(
sale_id VARCHAR(10) NOT NULL,   
customer_id varchar(10) NOT NULL,
customer_name VARCHAR( 30 )NOT NULL,
total_items VARCHAR( 10 ) NOT NULL,
grand_total VARCHAR( 10 ) NOT NULL,
record_date VARCHAR( 10 )NOT NULL,
 PRIMARY KEY (sale_id)
)