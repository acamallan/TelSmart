CREATE TABLE was_cs_product_location (
	was_id VARCHAR(3) not null,
	location VARCHAR(30) not null
);