CREATE TABLE was_cs_tariff (
was_id VARCHAR(3) NOT NULL PRIMARY KEY ,
tariff VARCHAR( 30 ) NOT NULL);
insert into was_cs_tariff(was_id, tariff)
values(101,'Tariff 1');
insert into was_cs_tariff(was_id, tariff)
values(102,'Tariff 2');
