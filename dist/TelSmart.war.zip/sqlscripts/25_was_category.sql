CREATE TABLE was_category(
was_id VARCHAR(30) PRIMARY KEY ,
category_name VARCHAR( 30 ) NOT NULL ,
parent_category VARCHAR( 30 ) NOT NULL ,
category_description VARCHAR( 30 ) NOT NULL 
)