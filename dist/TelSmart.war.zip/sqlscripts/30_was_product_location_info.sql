CREATE TABLE was_product_location_info (
	product_id VARCHAR(6) not null,
	location VARCHAR(3) not null,
	quantity VARCHAR(10)
);
