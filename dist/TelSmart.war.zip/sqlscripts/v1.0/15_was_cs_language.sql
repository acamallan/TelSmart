CREATE TABLE was_cs_language (
was_id VARCHAR(3) NOT NULL PRIMARY KEY ,
language VARCHAR( 30 ) NOT NULL);
insert into was_cs_language(was_id, language)
values(101,'English');
insert into was_cs_language(was_id, language)
values(102,'Filipino');