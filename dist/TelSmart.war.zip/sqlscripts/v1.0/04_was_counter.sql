delete from was_counter where counter_id ='010';
insert into was_counter(counter_id, counter_value, description)
values('010','1000000000','Link Number');

delete from was_counter where counter_id ='011';
insert into was_counter(counter_id, counter_value, description)
values('011','1000000000','Account Number');