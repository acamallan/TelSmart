alter table was_account_balance_details add customer_id varchar(10) not null;
alter table was_account_balance_details add link_number varchar(10) not null;