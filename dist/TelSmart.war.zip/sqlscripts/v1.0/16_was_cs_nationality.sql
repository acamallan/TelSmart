CREATE TABLE was_cs_nationality (
was_id VARCHAR(3) NOT NULL PRIMARY KEY ,
nationality VARCHAR( 30 ) NOT NULL);
insert into was_cs_nationality(was_id, nationality)
values(101,'Cambodian');
insert into was_cs_nationality(was_id, nationality)
values(102,'Indonesian');
insert into was_cs_nationality(was_id, nationality)
values(103,'Malaysian');
insert into was_cs_nationality(was_id, nationality)
values(104,'Burmese');
insert into was_cs_nationality(was_id, nationality)
values(105,'Filipino');
insert into was_cs_nationality(was_id, nationality)
values(106,'Singaporean');
insert into was_cs_nationality(was_id, nationality)
values(107,'Thai');
insert into was_cs_nationality(was_id, nationality)
values(108,'Vietnamese');