alter table was_user_info add 
last_logoff TIMESTAMP;