CREATE TABLE `was_customer_account` (
	`account_number` VARCHAR(10) NOT NULL,
	`record_date` VARCHAR(10) NOT NULL,
	`link_number` VARCHAR(10) NOT NULL,
	`customer_id` VARCHAR(10) NOT NULL,
	PRIMARY KEY (`account_number`)
)