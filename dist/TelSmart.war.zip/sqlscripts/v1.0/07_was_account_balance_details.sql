CREATE TABLE was_account_balance_details (
account_number VARCHAR(10) NOT NULL PRIMARY KEY,     
record_date VARCHAR(10) NOT NULL,
account_balance VARCHAR(10) NOT NULL);