alter table was_product_sales_invoice_header add room_id varchar(4) default '';
alter table was_product_sales_invoice_header add record_time varchar(8) default '';
alter table was_product_sales_invoice_header add payment_mode varchar(3) default '';