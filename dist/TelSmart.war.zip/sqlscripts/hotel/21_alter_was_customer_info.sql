alter table was_customer_info add id_type varchar(3) default '';
alter table was_customer_info add id_number varchar(15) default '';