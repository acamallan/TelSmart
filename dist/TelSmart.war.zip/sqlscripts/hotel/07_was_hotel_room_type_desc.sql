CREATE TABLE was_hotel_room_type_desc (
inc_id int NOT NULL AUTO_INCREMENT primary key, 
room_type VARCHAR(3) NOT NULL,
description varchar(50) not null
);