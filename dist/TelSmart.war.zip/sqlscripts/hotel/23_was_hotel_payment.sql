alter table was_hotel_payment add userid varchar(6) default '';
update was_hotel_payment set userid='100010';