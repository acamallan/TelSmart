alter table was_hotel_book_transactions add room_status varchar(3) default '';
alter table was_hotel_book_transactions_history add room_status varchar(3) default '';
