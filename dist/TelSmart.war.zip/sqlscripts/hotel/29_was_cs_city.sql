CREATE TABLE was_cs_city (
	was_id VARCHAR(3) not null,
	city VARCHAR(30) not null
);

insert into was_cs_city(was_id, city)
values('145','Iloilo');
insert into was_cs_city(was_id, city)
values('146','Roxas');
insert into was_cs_city(was_id, city)
values('147','Capiz');
insert into was_cs_city(was_id, city)
values('148','Passi');
insert into was_cs_city(was_id, city)
values('149','Makati');
insert into was_cs_city(was_id, city)
values('150','Manila');
commit;