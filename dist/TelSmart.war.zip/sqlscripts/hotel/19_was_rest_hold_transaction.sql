CREATE TABLE was_rest_hold_transaction(
sales_id varchar(10) not null primary key,
transaction_date VARCHAR( 10 ) NOT NULL,
transaction_time VARCHAR( 8 ) NOT NULL,
table_id VARCHAR( 3 ) NOT NULL
);