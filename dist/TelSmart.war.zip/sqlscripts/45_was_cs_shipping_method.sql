CREATE TABLE was_cs_shipping_method (
was_id VARCHAR(3) NOT NULL PRIMARY KEY ,
shipping_method VARCHAR( 30 ) NOT NULL);
insert into was_cs_shipping_method(was_id, shipping_method)
values(101,'Shipping Method 1');
insert into was_cs_shipping_method(was_id, shipping_method)
values(102,'Shipping Method 1');
