CREATE TABLE was_cs_gender (
was_id VARCHAR(3) NOT NULL PRIMARY KEY ,
gender VARCHAR( 30 ) NOT NULL);
insert into was_cs_gender(was_id, gender)
values(101,'Male');
insert into was_cs_gender(was_id, gender)
values(102,'Female');
