'use strict';
//#if TRUE
var i = 0;
while(i-->0) {
}
//#endif
